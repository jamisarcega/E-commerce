<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\Product;
use App\Status;
use Auth;
use Stripe;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return redirect()->route('landing')->with('login-success','Logged in');
    }
    public function history()
    {
        $orders = Order::where('user_id', Auth::user()->id)->where('status', 1)->get();

        return view('purchase-history', compact('orders'));
    }
    public function addToCart(Request $request, $id)
    {
        $find = Order::where('user_id', Auth::user()->id)->where('product_id', $id)->where('status', 0)->first();
        if($find == NULL){
            $new = new Order;
            $new->user_id = Auth::user()->id;
            $new->product_id = $id;
            $new->quantity = $request->quantity;
            $new->save();
        }
        else{
            $find->quantity = $request->quantity;
            $find->save();
        }

        return redirect()->back()->with('success', 'Order successfully added to your cart! ');

    }
    public function charge()
    {
        $client = new \GuzzleHttp\Client();
        $response = $client->request('GET', 'https://rebit.ph/api/v1/provinces');
        $body = $response->getBody();
        $content =$body->getContents();
        $provinces = json_decode($content,false);

        $orders = Order::where('user_id', Auth::user()->id)->where('status', '0')->get();
        $price = 0;
       
        if($orders){
            foreach($orders as $order){
                if($order->product->sale_percentage != NULL){
                    $sale = $order->product->price - (($order->product->sale_percentage/100)*$order->product->price);
           
                    $price += ($order->quantity * $sale);        
            
                }
                else{
                    $price += ($order->quantity * $order->product->price);
                }
            }
   
        }

        return view('sample',compact('price', 'provinces'));
    }
    public function checkout()
    {
        $client = new \GuzzleHttp\Client();
        $response = $client->request('GET', 'https://rebit.ph/api/v1/provinces');
        $body = $response->getBody();
        $content =$body->getContents();
        $provinces = json_decode($content,false);
        
        $orders = Order::where('user_id', Auth::user()->id)->where('status', '0')->get();
        $price = 0;
       
        if($orders){
            foreach($orders as $order){
                if($order->product->sale_percentage != NULL){
                    $sale = $order->product->price - (($order->product->sale_percentage/100)*$order->product->price);
           
                    $price += ($order->quantity * $sale);        
            
                }
                else{
                    $price += ($order->quantity * $order->product->price);
                }
            }
             return view('checkout',compact('price','orders','provinces'));
        }
       
            return view('checkout',compact('price','orders','provinces'));
        
         


    }
    public function billing(Request $request)
    {
        $orders = Order::where('user_id', Auth::user()->id)->where('status', '0')->get();
        $price = 0;
       
        if($orders){
            foreach($orders as $order){
                if($order->product->sale_percentage != NULL){
                    $sale = $order->product->price - (($order->product->sale_percentage/100)*$order->product->price);
           
                    $price += ($order->quantity * $sale);        
            
                }
                else{
                    $price += ($order->quantity * $order->product->price);
                }
            }
             
        }

        try {
            $charge = Stripe::charges()->create([
                'amount' => $price,
                'currency' => 'PHP',
                'source' => $request->stripeToken,
                'description' => 'Order',

            ]);
            $orders = Order::where('user_id', Auth::user()->id)->where('status', '0')->get();
            foreach($orders as $order){
                $order->status = 1;
                $order->save();

                $status = new Status;
                $status->order_id = $order->id;
                $status->status = 1;
                $status->save();
            }

            return redirect()->route('user.history')->with('success','Order(s) Placed! Track your products here');
        } catch (Exception $e) {
            //throw $th;
        }


    }
}
