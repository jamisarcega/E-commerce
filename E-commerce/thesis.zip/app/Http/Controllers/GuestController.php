<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Order;
use App\Tag;
use App\Image;
use Auth;
class GuestController extends Controller
{
    public function index()
    {
        $products = Product::where('status', 1)->paginate(8);
        $tags = Tag::get();
        
        return view('landing',compact('products','tags'));
    }
    public function viewProduct($id)
    {
        $product = Product::where('id',$id)->with('tags')->first();
    
        return view('view-product',compact('product'));
    }

    public function findProducts(Request $request)
    {  
        // not null : Whom
        if($request->tags == NULL && $request->gender == NULL && $request->whom != NULL){
             
            $products = Product::where('for_whom',$request->whom)
                                ->orWhere('for_whom','4')
                                ->where('status',1)
                                ->get();
     
            $output= ' ';

        }
        // not null: whom , gender
        if($request->gender != NULL && $request->whom != NULL && $request->tags == NULL){
            // $products = Product::where('for_whom',$request->whom)->where('status',1)->where('gender',$request->gender)->get();
            
            $products = Product::where('gender',$request->gender)
            ->orWhere('gender','3')
            ->where('for_whom',$request->whom)
            ->orWhere('for_whom',4)
            ->where('status',1)
            ->get();
         
            $output= ' ';
            //  return response($products);

        }
         // not null: whom , gender,tags
         if($request->gender != NULL && $request->whom != NULL && $request->tags != NULL){                     
            $output= ' ';
            $tags = $request->tags;
            $counter == 1;
            dd($output);
            foreach($tags as $tag){
                $findTag = Tag::find($tag)->first();
            

                    $filter = Product::whereHas('tags', function($q) use($findTag){
                        $q->where('tag_id', $findTag->id);
                    })
                        ->where('gender', $request->gender)
                        ->orWhere('gender', 3)
                        ->where('for_whom',$request->whom)
                        ->orWhere('for_whom',4)
                        ->where('status',1)
                        ->get();
          

            }
        //  dd($findTag->id);

            // return response($output);
        
        }
     
        foreach($products as $product){
            $image = Image::where('product_id' ,$product->id )->first();
            $sale= '';
            if($product->sale_percentage == NULL){
                $sale ='<strong>P '.$product->price.' </strong>';
            }
            else{
                $price = $product->price-($product->price / $product->sale_percentage);
                $sale='   <del class="grey-text">P '.$product->price.'</del>
                <strong>P '.$price.'</strong>';
            }
            $output .= '<div class="col-lg-3 col-md-6 mb-4">

            <!--Card-->
            <div class="card" style="height: 40vh;">
            <!--Card image-->
            <div class="view overlay">
            <img src="'.asset('uploads/images/'.$image->name).'" class="card-img-top img-responsive" alt="">
            <a href="'.route('viewProduct', $product->id).'">
            <div class="mask rgba-white-slight"></div>
            </a>
            </div>
            <!--Card image-->

            <!--Card content-->
            <div class="card-body text-center" >
            <!--Category & Title-->
        
                <h5>Shirt</h5>
            
            <h5>
                <strong>
                <a href="'.route('viewProduct', $product->id).'" class="dark-grey-text">'.$product->product_name.'
                    <!-- <span class="badge badge-pill danger-color">NEW</span> -->
              </a>
                </strong>
            </h5>

            <h4 class="font-weight-bold blue-text">'.$sale.'</h4>

            </div>
            <!--Card content-->

            </div>
            <!--Card-->

            </div> ';
        }
        if(count($products) < 1){
            $output = ' <h5>No results found.</h5>';

        }


        return response($output);
    }
}
