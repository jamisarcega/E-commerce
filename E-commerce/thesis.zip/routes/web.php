<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','GuestController@index')->name('landing');
Route::get('/view-product/{product}','GuestController@viewProduct')->name('viewProduct');
Route::get('/find/products/','GuestController@findProducts')->name('findProducts');
//stores
Route::get('/store/login', 'Auth\StoreLoginController@storeLogin')->name('store.login');
Route::post('/store/login', 'Auth\StoreLoginController@storeLoginSubmit')->name('store.loginSubmit');
Route::post('/store/logout', 'Auth\LoginController@logoutStore')->name('store.logout');
Route::get('/store/dashboard', 'StoreController@index')->name('store.index');
Route::get('/store/products', 'StoreController@products')->name('store.products');
Route::post('/store/add/products', 'StoreController@addProduct')->name('store.addProduct');
Route::post('/store/edit/product\{product}', 'StoreController@editProduct')->name('store.editProduct');
Route::get('/store/store/products/find/{id}', 'StoreController@findProduct')->name('store.findProduct');
Route::get('/store/store/products/filter', 'StoreController@filterProducts')->name('store.filterProducts');

Auth::routes();
Route::get('/home', 'HomeController@index')->name('user.home');
Route::post('/cart/add/{product}', 'HomeController@addToCart')->name('user.addToCart');
Route::get('/cart/checkout/', 'HomeController@checkout')->name('user.checkout');
Route::get('/cart/checkout/billing', 'HomeController@charge')->name('user.charge');
Route::post('/cart/checkout/billing', 'HomeController@billing')->name('user.billing');
Route::get('/puchase-history', 'HomeController@history')->name('user.history');

