@extends('layouts.user-layout')
@section('content')
  <main class="mt-5 pt-4">
    <div class="container dark-grey-text mt-5">

      <!--Grid row-->
      <div class="row wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 mb-4">

        <p style="display:none;">{{ $image = App\Image::where('product_id' ,$product->id )->first() }}</p>
                @if($image)
                  <img src="{{ asset('uploads/images/'.$image->name) }}" class="img-fluid" alt="">
                @else
                  <img src="{{ asset('uploads/images/no_photo.png') }}" class="img-fluid"  alt="">                    
                @endif

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-6 mb-4">

          <!--Content-->
          <div class="p-4">

            <div class="mb-3">
              <!-- <a href="">
                <span class="badge purple mr-1">Category 2</span>
              </a> -->
              <p class="grey-text"><strong>Seller: {{ $product->store->email }}</strong></p>
            
            </div>
           

            <p class="lead font-weight-bold">{{$product->product_name}}</p>
            @if($product->sale_percentage != NULL)
            <p class="lead">
              <span class="mr-1">
                <del>P {{ $product->price }}</del>
              </span>
              <span>P {{ $product->price-($product->price / $product->sale_percentage) }}</span>
              <span class="badge badge-danger">{{ $product->sale_percentage }}% SALE!</span>
            </p>
            @else
            <p class="lead">
              <span>P {{ $product->price}}</span>
            </p>
            @endif
            
              <p class="text-muted mb-n3">Tags</p><br>
              <div id="tags mb-n5">
                @foreach($product->tags as $tag)
                  <button class="btn btn-mdb-color btn-sm" disabled>{{ $tag->name }}</button>
                @endforeach
              </div>
              <hr>
            @if(Auth::check())
                  <p style="display: none">{{ $order = App\Order::where('user_id', Auth::user()->id)->where('status', 0)->where('product_id', $product->id)->first() }}</p>
                @if($order)
                  <form action="{{ route('user.addToCart', $product->id) }}" method="POST" class="d-flex justify-content-left">
                    <!-- Default input -->
                    @csrf
                    <input type="number" min="1" max="{{ $product->quantity }}" value="{{ $order->quantity }}" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
                    <button class="btn btn-primary btn-md my-0 p" type="submit">Update Cart
                      <i class="fas fa-shopping-cart ml-1"></i>
                    </button>

                  </form>
                @else
                  <form action="{{ route('user.addToCart', $product->id) }}" method="POST" class="d-flex justify-content-left">
                    <!-- Default input -->
                    @csrf
                    <input type="number" min="1" max="{{ $product->quantity }}" value="1" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
                    <button class="btn btn-primary btn-md my-0 p" type="submit">Add to cart
                      <i class="fas fa-shopping-cart ml-1"></i>
                    </button>

                  </form>  
                @endif
            @else
              <form action="{{ route('user.addToCart', $product->id) }}" method="POST" class="d-flex justify-content-left">
                <!-- Default input -->
                @csrf
                <input type="number" min="1" max="{{ $product->quantity }}" value="1" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
                <button class="btn btn-primary btn-md my-0 p" type="submit">Add to cart
                  <i class="fas fa-shopping-cart ml-1"></i>
                </button>

              </form>
            @endif
          

          </div>
          <!--Content-->

        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->

      <hr>

      <!--Grid row-->
      <div class="row d-flex justify-content-center wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 text-center">

          <h4 class="my-4 h4">Product Description</h4>

          <p>{{ $product->description }}</p>

        </div>
        <!--Grid column-->

      </div>
     
    

    </div>

  </main>

  <!--Main layout-->
@endsection

@section('scripts')
<script>
  $( document ).ready(function() {
    @if(session('success'))
        
          Swal.fire("{{ session('success') }}","","success");
 
    @endif   
  });
  </script>
@endsection