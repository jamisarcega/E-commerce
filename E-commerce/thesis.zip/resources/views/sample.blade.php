
@extends('layouts.user-layout')
@section('content')
<main class="mt-5 pt-4">
<div class="container wow fadeIn">
<h2 class="my-5 h2 text-center">Shipping and Billing</h2>
<link href="{{asset('mdb/css/stripe.css')}}" rel="stylesheet">

<script src="https://js.stripe.com/v3/"></script>

<form action="{{ route('user.billing') }}" method="POST" id="payment-form">
@csrf
<div class="card grey lighten-5 card-body">
<div class="row">

<!--Grid column-->
<div class="col-md-12 mb-2">
<small class="text-muted">Fill this form only if you want to send the items as a gift.</small>

</div>
<div class="col-md-6 mb-2">
  <!--firstName-->
  <div class="md-form ">
    <input type="text" id="firstName" class="form-control">
    <label for="firstName" class="">First name</label>
  </div>

</div>
<!--Grid column-->

<!--Grid column-->
<div class="col-md-6 mb-2">

  <!--lastName-->
  <div class="md-form">
    <input type="text" id="lastName" class="form-control">
    <label for="lastName" class="">Last name</label>
  </div>

</div>
<!--Grid column-->

</div>
    <div class="md-form mb-2">
        <input type="text" id="address" class="form-control" placeholder="1234 Main St">
        <label for="address" class="">Address</label>
    </div>
    <div class="md-form mb-2">
        <input type="text" id="address-2" class="form-control" placeholder="Apartment or suite">
        <label for="address-2" class="">Address 2 (optional)</label>
    </div>
            <!--Grid row-->
            <div class="row">

<!--Grid column-->
<div class="col-lg-4 col-md-12 mb-4">

  <label for="country">Province</label>
  <select class="custom-select d-block w-100" id="province" >
    <option value="">Choose...</option>
     @foreach($provinces as $province)
     <option value="{{ $province }}">{{ $province }}</option>
     
     @endforeach
  </select>
  <div class="invalid-feedback">
    Please select a valid province.
  </div>

</div>
<!--Grid column-->

<!--Grid column-->
<div class="col-lg-4 col-md-6 mb-4">

  <label for="state">City</label>
  <input type="text" class="form-control" id="city" placeholder="" >
  <div class="invalid-feedback">
    Please provide a valid state.
  </div>

</div>
<!--Grid column-->

<!--Grid column-->
<div class="col-lg-4 col-md-6 mb-4">

  <label for="zip">Zip</label>
  <input type="text" class="form-control" id="zip" placeholder="" >
  <div class="invalid-feedback">
    Zip code required.
  </div>

</div>
<!--Grid column-->

</div>
<!--Grid row-->

<hr>
  
  <div class="form-row" style="display:inline-block;">
    <label for="card-element">
      Credit or debit card
    </label>
    <div id="card-element">
      <!-- A Stripe Element will be inserted here. -->
    </div>

    <!-- Used to display form errors. -->
    <div id="card-errors" role="alert"></div>
  </div>
<br>
@if($price != 0)
  <button class="btn btn-secondary">Pay P{{$price}}</button>
@else
<button class="btn btn-secondary disabled">You don't have any orders.</button>

@endif  
  </div>
</form>


<script>
// Create a Stripe client.
var stripe = Stripe('pk_test_PZ3OutMktqNGSmTcpiccOr0i00yj62A64O');

// Create an instance of Elements.
var elements = stripe.elements();

// Custom styling can be passed to options when creating an Element.
// (Note that this demo uses a wider set of styles than the guide below.)
var style = {
  base: {
    color: '#32325d',
    fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
    fontSmoothing: 'antialiased',
    fontSize: '16px',
    '::placeholder': {
      color: '#aab7c4'
    }
  },
  invalid: {
    color: '#fa755a',
    iconColor: '#fa755a'
  }
};

// Create an instance of the card Element.
var card = elements.create('card', {style: style});

// Add an instance of the card Element into the `card-element` <div>.
card.mount('#card-element');

// Handle real-time validation errors from the card Element.
card.addEventListener('change', function(event) {
  var displayError = document.getElementById('card-errors');
  if (event.error) {
    displayError.textContent = event.error.message;
  } else {
    displayError.textContent = '';
  }
});

// Handle form submission.
var form = document.getElementById('payment-form');
form.addEventListener('submit', function(event) {
  event.preventDefault();

  stripe.createToken(card).then(function(result) {
    if (result.error) {
      // Inform the user if there was an error.
      var errorElement = document.getElementById('card-errors');
      errorElement.textContent = result.error.message;
    } else {
      // Send the token to your server.
      stripeTokenHandler(result.token);
    }
  });
});

// Submit the form with the token ID.
function stripeTokenHandler(token) {
  // Insert the token ID into the form so it gets submitted to the server
  var form = document.getElementById('payment-form');
  var hiddenInput = document.createElement('input');
  hiddenInput.setAttribute('type', 'hidden');
  hiddenInput.setAttribute('name', 'stripeToken');
  hiddenInput.setAttribute('value', token.id);
  form.appendChild(hiddenInput);

  // Submit the form
  form.submit();
}
</script>
</div>
</main>
@endsection