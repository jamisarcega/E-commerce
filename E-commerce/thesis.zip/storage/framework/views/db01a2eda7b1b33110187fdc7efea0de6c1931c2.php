<?php $__env->startSection('content'); ?>
<main class="mt-5 pt-4">
<div class="container wow fadeIn">
<h2 class="my-5 h2 text-center">Purchase History</h2>
 <div class="card">
    <div class="card-body">
    <table id="table_id" class="table table-striped" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Date</th>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->updated_at); ?></td>
                    <td><?php echo e($order->product->product_name); ?></td>
                    <td><?php echo e($order->quantity); ?></td>
                    <?php if($order->product->sale_percentage != NULL): ?>
                        <td>P<?php echo e(($order->product->price -(($order->product->sale_percentage / 100) *$order->product->price))*$order->quantity); ?></td>
                    <?php else: ?>
                        <td>P<?php echo e($order->product->price * $order->quantity); ?></td>
                    <?php endif; ?>
                    <td>
                        <button class="btn btn-secondary btn-sm" data-toggle="modal" data-target="#history<?php echo e($order->id); ?>">View  &nbsp<i class="fas fa-caret-right"></i></button>
                      
                    </td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
 </div>
</div>

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade right" id="history<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-full-height modal-right" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #AA67CC; color:white;">
        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-truck"></i> Track Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <h2 class="h1-responsive font-weight-bold text-center my-5"><?php echo e($order->product->product_name); ?></h2>
            <p style="display:none;"><?php echo e($status = App\Status::where('order_id', $order->id)->first()); ?></p>
        <?php if($status->status == 1): ?>
            <blockquote class="blockquote">
                <p class="mb-0 h1"><i class="fas fa-money-bill text-default"></i> Payment Received &nbsp&nbsp<span class="badge badge-pill badge-secondary"><sub><?php echo e($status->updated_at); ?></sub></span></p> 
                <footer class="blockquote-footer">Waiting for the supplier to ship your product.</footer>
            </blockquote>
        <?php elseif($status->status == 2): ?>
            <blockquote class="blockquote">
                <p class="mb-0 h1"><i class="fas fa-archive text-warning"></i> Parcel is on the way!&nbsp&nbsp <span class="badge badge-pill badge-secondary"><sub><?php echo e($status->updated_at); ?></sub></span></p>
                <footer class="blockquote-footer">Please wait for the arrival of your product.</footer>
            </blockquote>
            <br>
            <blockquote class="blockquote">
                <p class="mb-0"><i class="fas fa-money-bill text-default"></i> Payment Received</p>
                <footer class="blockquote-footer">Waiting for the supplier to ship your product.</footer>
            </blockquote>
        <?php endif; ?>    

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready( function () {
    $('#table_id').DataTable();

    <?php if(session('success')): ?>
        
        Swal.fire("<?php echo e(session('success')); ?>","","success");

  <?php endif; ?>   
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\thesis\resources\views/purchase-history.blade.php ENDPATH**/ ?>