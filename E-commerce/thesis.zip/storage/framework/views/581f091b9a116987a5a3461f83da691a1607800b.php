<?php $__env->startSection('content'); ?>
  <main class="mt-5 pt-4">
    <div class="container dark-grey-text mt-5">

      <!--Grid row-->
      <div class="row wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 mb-4">

        <p style="display:none;"><?php echo e($image = App\Image::where('product_id' ,$product->id )->first()); ?></p>
                <?php if($image): ?>
                  <img src="<?php echo e(asset('uploads/images/'.$image->name)); ?>" class="img-fluid" alt="">
                <?php else: ?>
                  <img src="<?php echo e(asset('uploads/images/no_photo.png')); ?>" class="img-fluid"  alt="">                    
                <?php endif; ?>

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-6 mb-4">

          <!--Content-->
          <div class="p-4">

            <div class="mb-3">
              <!-- <a href="">
                <span class="badge purple mr-1">Category 2</span>
              </a> -->
              <p class="grey-text"><strong>Seller: <?php echo e($product->store->email); ?></strong></p>
            
            </div>
           

            <p class="lead font-weight-bold"><?php echo e($product->product_name); ?></p>
            <?php if($product->sale_percentage != NULL): ?>
            <p class="lead">
              <span class="mr-1">
                <del>P <?php echo e($product->price); ?></del>
              </span>
              <span>P <?php echo e($product->price-($product->price / $product->sale_percentage)); ?></span>
              <span class="badge badge-danger"><?php echo e($product->sale_percentage); ?>% SALE!</span>
            </p>
            <?php else: ?>
            <p class="lead">
              <span>P <?php echo e($product->price); ?></span>
            </p>
            <?php endif; ?>
            
              <p class="text-muted mb-n3">Tags</p><br>
              <div id="tags mb-n5">
                <?php $__currentLoopData = $product->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn btn-mdb-color btn-sm" disabled><?php echo e($tag->name); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <hr>
            <?php if(Auth::check()): ?>
                  <p style="display: none"><?php echo e($order = App\Order::where('user_id', Auth::user()->id)->where('status', 0)->where('product_id', $product->id)->first()); ?></p>
                <?php if($order): ?>
                  <form action="<?php echo e(route('user.addToCart', $product->id)); ?>" method="POST" class="d-flex justify-content-left">
                    <!-- Default input -->
                    <?php echo csrf_field(); ?>
                    <input type="number" min="1" max="<?php echo e($product->quantity); ?>" value="<?php echo e($order->quantity); ?>" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
                    <button class="btn btn-primary btn-md my-0 p" type="submit">Update Cart
                      <i class="fas fa-shopping-cart ml-1"></i>
                    </button>

                  </form>
                <?php else: ?>
                  <form action="<?php echo e(route('user.addToCart', $product->id)); ?>" method="POST" class="d-flex justify-content-left">
                    <!-- Default input -->
                    <?php echo csrf_field(); ?>
                    <input type="number" min="1" max="<?php echo e($product->quantity); ?>" value="1" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
                    <button class="btn btn-primary btn-md my-0 p" type="submit">Add to cart
                      <i class="fas fa-shopping-cart ml-1"></i>
                    </button>

                  </form>  
                <?php endif; ?>
            <?php else: ?>
              <form action="<?php echo e(route('user.addToCart', $product->id)); ?>" method="POST" class="d-flex justify-content-left">
                <!-- Default input -->
                <?php echo csrf_field(); ?>
                <input type="number" min="1" max="<?php echo e($product->quantity); ?>" value="1" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
                <button class="btn btn-primary btn-md my-0 p" type="submit">Add to cart
                  <i class="fas fa-shopping-cart ml-1"></i>
                </button>

              </form>
            <?php endif; ?>
          

          </div>
          <!--Content-->

        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->

      <hr>

      <!--Grid row-->
      <div class="row d-flex justify-content-center wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 text-center">

          <h4 class="my-4 h4">Product Description</h4>

          <p><?php echo e($product->description); ?></p>

        </div>
        <!--Grid column-->

      </div>
     
    

    </div>

  </main>

  <!--Main layout-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  $( document ).ready(function() {
    <?php if(session('success')): ?>
        
          Swal.fire("<?php echo e(session('success')); ?>","","success");
 
    <?php endif; ?>   
  });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\thesis\resources\views/view-product.blade.php ENDPATH**/ ?>