
@extends('layouts.user-layout')
@section('content')
<main class="mt-5 pt-4">
<div class="container wow fadeIn">
<h2 class="my-5 h2 text-center">Purchase History</h2>
 <div class="card">
    <div class="card-body">
    <table id="table_id" class="table table-striped" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Date</th>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($orders as $order)
                <tr>
                    <td>{{ $order->updated_at }}</td>
                    <td>{{ $order->product->product_name }}</td>
                    <td>{{ $order->quantity }}</td>
                    @if($order->product->sale_percentage != NULL)
                        <td>P{{ ($order->product->price -(($order->product->sale_percentage / 100) *$order->product->price))*$order->quantity }}</td>
                    @else
                        <td>P{{ $order->product->price * $order->quantity }}</td>
                    @endif
                    <td>
                        <button class="btn btn-secondary btn-sm" data-toggle="modal" data-target="#history{{ $order->id }}">View  &nbsp<i class="fas fa-caret-right"></i></button>
                      
                    </td>
                </tr>
                
            @endforeach
        </tbody>
    </table>
    </div>
 </div>
</div>

@foreach($orders as $order)
<div class="modal fade right" id="history{{$order->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-full-height modal-right" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #AA67CC; color:white;">
        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-truck"></i> Track Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <h2 class="h1-responsive font-weight-bold text-center my-5">{{ $order->product->product_name }}</h2>
            <p style="display:none;">{{ $status = App\Status::where('order_id', $order->id)->first() }}</p>
        @if($status->status == 1)
            <blockquote class="blockquote">
                <p class="mb-0 h1"><i class="fas fa-money-bill text-default"></i> Payment Received &nbsp&nbsp<span class="badge badge-pill badge-secondary"><sub>{{ $status->updated_at }}</sub></span></p> 
                <footer class="blockquote-footer">Waiting for the supplier to ship your product.</footer>
            </blockquote>
        @elseif($status->status == 2)
            <blockquote class="blockquote">
                <p class="mb-0 h1"><i class="fas fa-archive text-warning"></i> Parcel is on the way!&nbsp&nbsp <span class="badge badge-pill badge-secondary"><sub>{{ $status->updated_at }}</sub></span></p>
                <footer class="blockquote-footer">Please wait for the arrival of your product.</footer>
            </blockquote>
            <br>
            <blockquote class="blockquote">
                <p class="mb-0"><i class="fas fa-money-bill text-default"></i> Payment Received</p>
                <footer class="blockquote-footer">Waiting for the supplier to ship your product.</footer>
            </blockquote>
        @endif    

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
@endforeach

</main>

@endsection
@section('scripts')
<script>
$(document).ready( function () {
    $('#table_id').DataTable();

    @if(session('success'))
        
        Swal.fire("{{ session('success') }}","","success");

  @endif   
} );
</script>

@endsection